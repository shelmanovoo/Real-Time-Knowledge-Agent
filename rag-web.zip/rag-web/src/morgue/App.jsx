import { useState } from "react";

export default function App() {
  const [query, setQuery] = useState("");
  const [chat, setChat] = useState([]);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    // Добавляем сообщение пользователя в чат
    const userMessage = { sender: "user", text: query };
    setChat((prev) => [...prev, userMessage]);
    setLoading(true);

    try {
      const response = await fetch("http://192.168.1.37:5678/webhook/rag_query", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query }),
      });

      const data = await response.json();

      // Добавляем ответ AI в чат
      const aiMessage = {
        sender: "ai",
        text: data.answer || data.results || JSON.stringify(data),
      };
      setChat((prev) => [...prev, aiMessage]);
    } catch (err) {
      const errorMessage = { sender: "ai", text: "Ошибка при подключении к AI." };
      setChat((prev) => [...prev, errorMessage]);
      console.error(err);
    }

    setQuery("");
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center p-4">
      <h1 className="text-3xl font-bold mb-4">RAG AI Assistant</h1>

      <div className="w-full max-w-xl bg-white rounded shadow p-4 flex flex-col gap-4 mb-4 overflow-y-auto" style={{ maxHeight: "70vh" }}>
        {chat.length === 0 ? (
          <p className="text-gray-500">Начни диалог с AI, введя запрос ниже.</p>
        ) : (
          chat.map((msg, i) => (
            <div
              key={i}
              className={`p-2 rounded ${
                msg.sender === "user" ? "bg-blue-100 self-end text-right" : "bg-gray-200 self-start"
              }`}
            >
              {msg.text}
            </div>
          ))
        )}
      </div>

      <form onSubmit={handleSubmit} className="w-full max-w-xl flex">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Введите ваш вопрос..."
          className="flex-1 p-2 border border-gray-300 rounded-l focus:outline-none focus:ring-2 focus:ring-blue-400"
        />
        <button
          type="submit"
          className="bg-blue-600 text-white px-4 rounded-r hover:bg-blue-700 disabled:opacity-50"
          disabled={loading}
        >
          {loading ? "Загрузка..." : "Отправить"}
        </button>
      </form>
    </div>
  );
}
